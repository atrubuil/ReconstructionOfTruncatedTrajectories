function kinem = estim_v_sigma(Segment,t2D_trans,delta_t)
for i = 1:size(Segment,1)
    seg_i = Segment(i,:);
    traj_i = t2D_trans{seg_i.Index};
    seg_i_pos=traj_i((seg_i.time_entry-traj_i(1,3)+1:seg_i.time_exit-traj_i(1,3)+1),1:2);
    x_t0=seg_i_pos(:,1);
    y_t0=seg_i_pos(:,2);
    x_diff = diff(x_t0);
    y_diff = diff(y_t0);
    v_x(i)=(x_t0(end)-x_t0(1))/((length(x_t0)-1)*delta_t);
    v_y(i)=(y_t0(end)-y_t0(1))/((length(y_t0)-1)*delta_t);
    sigma_x2(i)=sum(x_diff.^2)/(length(x_diff)*delta_t)-abs(v_x(i))^2*delta_t;
    sigma_y2(i) = sum(y_diff.^2)/(length(y_diff)*delta_t)-abs(v_y(i))^2*delta_t;
end
    kinem = [v_x' v_y' sigma_x2' sigma_y2'];
    kinem = array2table(kinem);
    kinem.Properties.VariableNames={'v_x','v_y','sigma_x2','sigma_y2'};
end