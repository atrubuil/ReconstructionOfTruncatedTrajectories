% Copyright (c) 2020 INRAE - MaIAGE - France.
% Y. Lu, P. Hodara, C. Kervrann, A. Trubuil
function [t2D, t3D, traj_sejour, nb_track] = Simu6_film(sigma,v0, theta0, delta_t,lambda,tau_d,vstat,vdir,dura)
% Simulation of trajectories
% Input: sigma: diffusion coefficient
%        v0: drift
%        theta0: tan(theta0)=v_y/v_x
%        delta_t: time interval between two images
%        lambda : birth rate
%        tau_d: death rate
%        vstat: 0 (constant speed); 1 (speed different among trajectories)
%        vdir: 0 (v_x is positive); 1 (v_x can be positive or negative)
%        dura: The duration of simulated film, in minute
% Author: Y. Lu
% Date: 130520


%% Parameters of simulation
mu=1/lambda;% lambda is birth rate
%The length of the trajectory
n=round(dura*60/delta_t);%
%The diffusion coefficient
Sigma=sigma*eye(2);
% fig2=2;% To display the cylinder and the trajs on its surface
% fig3=3;% To display the unwrapping trajectories
fig2=0;
fig3=0;

if fig2>0
    figure(fig2);
    [X,Y,Z] = cylinder(50/(2*pi),100);
    surf(Z*30,Y,X-min(X(1,:)),'FaceAlpha',0.3, 'EdgeColor', [1 1 1]);
end
id=1;
traj_sejour = [];
t2D= {};
nb_track=zeros(1,1);
sgn=zeros(1,1);
for k = 1:300
    if vdir==1
        sgn(id) = 2*((rand(1)<0.5)-0.5); % The directions of tracks are a random
    elseif vdir==0
        sgn(id) = 1; % All trajs have the same moving direction
    end
    
    bt(id) = round(exprnd(mu)/delta_t);
    borntime = sum(bt);
    if borntime>n
        break
    end
    D_t = exprnd(1/tau_d);%The unit of D_t is in second
    length_t = round(D_t/delta_t);
    X_ini = [unifrnd(0,50,1,1),unifrnd(0,30,1,1)]';
    if vstat
        v1=sgn(id)*unifrnd(v0-0.2,v0+0.2);
    else
        v1=v0*sgn(id);
    end
    if borntime ==0
        borntime =1;
    end
    traj_sejour=[traj_sejour;[id borntime length_t+borntime v1]];
    
    t2D{id,borntime}=X_ini;
    
    theta = 2*pi*X_ini(1)/50;
    X_axe = 50/(2*pi)*sin(theta);
    Y_axe = X_ini(2);
    Z_axe = 50/(2*pi)*(1-cos(theta));
    t3D{id,borntime}=[X_axe Y_axe Z_axe];
    
    if id == 1
        last_bt=1;
    else
        last_bt = traj_sejour(id-1,2);
    end
    if borntime >1
        for tn =last_bt:(borntime-1)
            ind=(traj_sejour(:,2)<=tn)&(traj_sejour(:,3)>tn);
            if sum(ind)~=0
                Id=traj_sejour(ind,1);
                for id_t = Id'
                    epsilon=randn(2,1);
                    mat_cov=sqrt(delta_t)*Sigma;
                    v1= traj_sejour(id_t,4);
                    v = v1*[1;tan(theta0)];
                    drift=v*delta_t;
                    increment=drift+mat_cov*epsilon;
                    new_point=t2D{id_t,tn}+increment;
                    if new_point(2)>30 ||new_point(2)<0
                        traj_sejour(id_t,3)=tn;
                    else
                        rem_x = rem(new_point(1),50);
                        if rem_x>=0
                            new_point(1) = rem_x;
                        else
                            new_point(1) = rem_x+50;
                        end
                        
                        t2D{id_t,tn+1}=new_point;
                        theta = 2*pi*new_point(1)/50;
                        X_axe = 50/(2*pi)*sin(theta);
                        Y_axe = new_point(2);
                        Z_axe = 50/(2*pi)*(1-cos(theta));
                        t3D{id_t,tn+1}=[X_axe Y_axe Z_axe];
                        
                        %Draw a 3D trajectory
                        if fig2>0
                            figure(fig2)
                            hold on
                            axis([-10 40 -10 10 0 16])
                            scatter3(Y_axe,X_axe,Z_axe,'.')
                        end
                        if fig3>0
                            figure(fig3);
                            hold on
                            scatter(new_point(2),new_point(1),'.')
                            xlim([-10 40]);
                            ylim([0 50]);
                            daspect([1 1 1])
                        end
                    end
                    
                    
                end
            end
            nb_track(tn)=sum(ind);
            %                 figure(2)
            %                 scatter(1:tn,nb_track,'.');
        end
    end
    id=id+1;
end
traj_sejour((traj_sejour(:,3)>size(t2D,2)),3)=size(t2D,2);

end