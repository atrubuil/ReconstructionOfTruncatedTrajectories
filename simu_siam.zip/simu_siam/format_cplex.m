function B=format_cplex(A,nb_e,nb_s,Segment)

[row, col]=find(reshape(A,[nb_e nb_s]));
Position = [row col];
B=zeros(size(Segment,1),1);
cum_id=1;
for i = 1:size(Position,1)
    part1=find(Segment.ID_sortie==Position(i,2));
    part2=find(Segment.ID_entree==Position(i,1));
    if B(part1)==0
    B([part1 part2])=cum_id;
    cum_id = cum_id +1;
    else
        B(part2)=B(part1);
    end
end
B(B==0)=cum_id:(cum_id+sum(B==0)-1);
end