function [Entree,Sortie,tau_alpha_hat2] = tau_alpha_estimation2(l_u,l_1,t2D_trans,traj_sejour,T_0,delta_t)
nb = floor(l_u/l_1);
rem = mod(l_u,l_1);
    
if rem>0
    [~,Sortie_part]=EntreeSorite2(t2D_trans,traj_sejour,rem);
    if size(Sortie_part,1)>0
    p_1 = sum(Sortie_part.born_in(Sortie_part.time_entry~=1))/sum(Sortie_part.time_entry~=1);
    else
        p_1=0;
    end
else
    p_1=0;
end

[Entree,Sortie]=EntreeSorite2(t2D_trans,traj_sejour,l_1);

if nb == 1
    p_le = p_1;
elseif nb==2
    p_l=sum(Sortie.born_in(Sortie.time_entry~=1))/sum(Sortie.time_entry~=1);
    p_le=(p_l + (1-p_l)*p_1);
end
if ~isempty(Sortie.time_exit(Sortie.time_entry==1))
trunc_time = max(Sortie.time_exit(Sortie.time_entry==1))*delta_t;
else trunc_time = 0;
end
tau_alpha_hat2 = (sum(Sortie.born_in(Sortie.time_entry~=1))+sum(~Sortie.born_in(Sortie.time_entry~=1))*p_le)/(T_0-trunc_time);
end