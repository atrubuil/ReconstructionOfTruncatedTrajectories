function cost = cost_matrix2(Entree,Sortie,tau_d,tau_alpha,Segment,delta_t,kinem,l_1)

H=30;
%prob_a_i = prob_a(T_0,tau_alpha,epsilon_t,epsilon_s,H);

% Prob_M_c
%prob_m_i = prob_m(v_x,sigma_x,l_1,hat_tau_d_partial);

% probability of b_c
%prob_connection = prob_c(e,s,delta_t,hat_tau_d_partial,v_x,sigma_x);

Cost_conn = zeros(size(Entree,1),size(Sortie,1));
Cost_die = zeros(size(Entree,1),size(Sortie,1));
Cost_birth = zeros(size(Entree,1),size(Sortie,1));

for p = 1:size(Sortie,1)
    if kinem == "true"
    v_x = Segment.v_x_true(Segment.ID_sortie==p);
    sigma_x = sqrt(Segment.sigma2_true(Segment.ID_sortie==p));
    v_y = Segment.v_y_true(Segment.ID_sortie==p);
    sigma_y = sigma_x;
    elseif kinem == "estim"
        v_x = Segment.v_x(Segment.ID_sortie==p);
        v_y = Segment.v_y(Segment.ID_sortie==p);
        sigma_x = sqrt(Segment.sigma_x2(Segment.ID_sortie==p));
        sigma_y = sqrt(Segment.sigma_y2(Segment.ID_sortie==p));
    end
    for q = 1:size(Entree,1)
        sortie = Sortie(p,:);
        entree = Entree(q,:);
        if sortie.time_exit>entree.time_entry
            Cost_conn(q,p)=Inf;
        else
            prob_c_i = prob_c(entree,sortie,delta_t,tau_d,v_x,v_y,sigma_x,sigma_y,l_1);
            Cost_conn(q,p)=-log(prob_c_i);
        end
    end
    prob_m_i = prob_m(v_x,sigma_x,l_1,tau_d);
    Cost_die(:,p) = -log(prob_m_i);
end

for q = 1:size(Entree,1)
    prob_a_i = prob_a(tau_alpha,H);
    Cost_birth(q,:)=-log(prob_a_i);
end

cost = Cost_conn-Cost_birth-Cost_die;
end
function P = prob_a(tau_alpha,H)
P=(tau_alpha/H);
end
function P = prob_m(v_x,sigma_x,l_1,tau_d)
% mu_ig_m = (50-l_1)/v_x;
% lambda_ig_m = ((50-l_1)/sigma_x)^2;
% pdf_ig = @(x) pdf('InverseGaussian',x,mu_ig_m,lambda_ig_m);
% g = @(x,y) tau_d*exp(-tau_d*y).*pdf_ig(x);
% ymin = @(x) x;
% P = integral2(g, 0, Inf,0,ymin);

f = @(x) (50-l_1)*(1-exp(-tau_d*x))./(sigma_x*sqrt(2*pi*x.^3)).*exp(-(v_x.*x-(50-l_1)).^2./(2*sigma_x^2*x));
P = integral(f,0,Inf);
end
function P=prob_c(e,s,delta_t,tau_d,v_x,v_y,sigma_x,sigma_y,l_1)
mu_ig_m = (50-l_1)/v_x;
lambda_ig_m = ((50-l_1)/sigma_x)^2;
t_cross = (e.time_entry-s.time_exit)*delta_t;
prob_su = exp(-tau_d*t_cross);
% fun = @(x) pdf('InverseGaussian',x,mu_ig_m,lambda_ig_m);
% prob_t = integral(fun,t_cross-epsilon_t,t_cross+epsilon_t);
prob_t = pdf('InverseGaussian',t_cross,mu_ig_m,lambda_ig_m);
%v_y = v_x*tan(0.01);
%sigma_y = 0.2;
% p_normal = @(x) pdf('Normal',x,v_y*t_cross+s(1),sqrt(t_cross)*sigma_y);
% prob_sp = integral(p_normal,e(1)-epsilon_s,e(1)+epsilon_s);
prob_sp = pdf('Normal',e.pos_entry,v_y*t_cross+s.pos_exit,sqrt(t_cross)*sigma_y);
P = prob_su*prob_t*prob_sp;
end