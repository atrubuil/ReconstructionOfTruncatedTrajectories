function [traj_sejour,t2D,t2D_trans,t3D,t3D_trans,nb_track]=trunc_gene_data(trunc_value,traj_sejour_0,t2D_0,t3D_0,nb_track0)
%Function truc_gene_data() takes as input the outputs of function
%Simu_film(). It truncates the movie from the moment fixed by the user until the end of the movie.
%Input: trunc_value: The moment of truncation (time/delta_t)
%       traj_sejour_0, t2D_0, t3D_0, nb_track0 are the ouputs of the
%       function Simu_film()
%Author: Y. Lu
%Date: 130520
traj_sejour = traj_sejour_0;
traj_sejour(traj_sejour(:,3)<trunc_value,:)=[];
traj_sejour(traj_sejour(:,2)<trunc_value,2)=trunc_value;
traj_sejour(:,2:3)=traj_sejour(:,2:3)-trunc_value+1;
t2D = t2D_0(traj_sejour(:,1),trunc_value:end);
t3D = t3D_0(traj_sejour(:,1),trunc_value:end);
traj_sejour(:,1)=1:size(traj_sejour,1);
nb_track = nb_track0(trunc_value:end);

dim_t2D = size(t2D);
t2D_trans={}; % A cell array, each cell containing the 2D coordonnates and the moment of points
t3D_trans={}; % A cell array, each cell containing the 3D coordonnates and the moment of points
for i = 1:dim_t2D(1)
    point_s = traj_sejour(i,2);
    point_e = traj_sejour(i,3);
    traj_i = [];
    traj_i_3D = [];
    for j = point_s:point_e
        traj_i = [traj_i;[t2D{i,j}' j]];
        traj_i_3D = [traj_i_3D;[t3D{i,j} j]];
    end
    t2D_trans{i}=traj_i;
    t3D_trans{i}=traj_i_3D;
end
end