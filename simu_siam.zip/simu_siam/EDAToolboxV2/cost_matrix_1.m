function [cost,assignment] = cost_matrix_1(traj_sejour,Segment,Entree,Sortie,rate)
Cost_a = zeros(size(Segment,1));

sigma_x = 0.2;
delta_t = 0.25;
l_1 = 7.3792*2;
epsilon_t=1;
epsilon_s=1;
for i = 1:size(Segment,1)
    sg_i=Segment(i,:);
    if isnan(sg_i(2))
        Cost_a(:,i)=Inf;
    else
        for j = 1:size(Segment,1)
            sg_j = Segment(j,:);
            if sg_i(4)<sg_j(3)
                sortie = Sortie(sg_i(2),:);
                entree = Entree(sg_j(1),:);
                v_x = traj_sejour(Segment(i,5),4);        
                prob_c_i = prob_c_2(entree,sortie,delta_t,v_x,sigma_x,l_1,epsilon_t,epsilon_s);
                Cost_a(j,i)=-log(prob_c_i);
            else
                Cost_a(j,i)=Inf;                
            end
        end
    end

end
result = Cost_a;
nb_seg = size(result,1);
result_r = reshape(result,[],1);
b=quantile(result_r(~isinf(result_r)),rate);

cost = [result b*eye(nb_seg);b*eye(nb_seg) result' ]';
%Cost_faux = [result_faux d*eye(nb_seg);b*eye(nb_seg) result_faux' ]';
cost(isnan(cost)|cost==0)=Inf;
%Cost_faux(isnan(Cost_faux)|Cost_faux==0)=Inf;
[assignment,C]=munkres(cost);

end


function P=prob_c_2(e,s,delta_t,v_x,sigma_x,l_1,epsilon_t,epsilon_s)
% When we dont consider the trajectory can not survive
mu_ig_m = (50-l_1)/v_x;
lambda_ig_m = ((50-l_1)/sigma_x)^2;
t_cross = (e(2)-s(2))*delta_t;
% fun = @(x) pdf('InverseGaussian',x,mu_ig_m,lambda_ig_m);
% prob_t = integral(fun,t_cross-epsilon_t,t_cross+epsilon_t);
prob_t = epsilon_t*pdf('InverseGaussian',t_cross,mu_ig_m,lambda_ig_m);
v_y = v_x*tan(0.01);
sigma_y = 0.2;
% p_normal = @(x) pdf('Normal',x,v_y*t_cross+s(1),sqrt(t_cross)*sigma_y);
% prob_sp = integral(p_normal,e(1)-epsilon_s,e(1)+epsilon_s);
prob_sp = epsilon_s*pdf('Normal',e(1),v_y*t_cross+s(1),sqrt(t_cross)*sigma_y);
P = prob_t*prob_sp;
end
