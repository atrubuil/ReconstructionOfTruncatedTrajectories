function [Entree,Sortie,x]=EntreeSorite2(t2D_trans,traj_sejour,bound)
% %%%%%%%%%%%%%%% %
% The entrance line is fixed at y = 0
% bound is the length of the used zone of the observed zone
% b_l = # segments born in the used zone and arrived at the bound/ # all segments going through the zone and arrived
% at the bound
% %%%%%%%%%%%%%%% %
w = warning ('off','all');
dim_t2D = size(t2D_trans);
Sortie = [];
Entree = [];
count_e = 0;
count_s = 0;
x=[];
for i = 1:dim_t2D(2)
    traj_i = t2D_trans{i};
    % It is this value to be changed, if we want
    % to change the visible portion
    %border_value = 24.9;
    ind_sortie = (traj_i(:,1)>bound);
    traj_i=[traj_i ind_sortie];
    ind_sortie1=find(diff(ind_sortie)==1);
    ind_entree1=find(diff(ind_sortie)==-1)+1;
    
    %     ind_entree1=find(diff(ind_sortie)& ~diff(ind_entree));
    %     ind_sortie1=find(diff(ind_entree)& ~diff(ind_sortie))+1;
    %
    % tracks return back in the border, which makes very short segments,
    % the following codes is aimed to resolve this problem
    clean_track_s = diff(ind_sortie1)<20;
    if sum(clean_track_s)~=0
        nb_cl = find(clean_track_s);
        for nb_cli = 1:size(nb_cl,1)
            ind_cl = nb_cl(nb_cli);
        ind_in = find(ind_entree1<=ind_sortie1(ind_cl+1)&ind_entree1>=ind_sortie1(ind_cl));
        ind_entree1(ind_in(1))=[];
        end
        ind_sortie1(nb_cl)=[];
    end
    
     clean_track_e = diff(ind_entree1)<20;
    if sum(clean_track_e)~=0
        nb_cl = find(clean_track_e);
        for nb_cli = 1:size(nb_cl,1)
            ind_cl = nb_cl(nb_cli);
        ind_in = find(ind_sortie1<=ind_entree1(ind_cl+1)&ind_sortie1>=ind_entree1(ind_cl));
        ind_sortie1(ind_in(1))=[];
        end
        ind_entree1(clean_track_e)=[];
    end
    
    if ~isempty(ind_sortie1) && ~isempty(ind_entree1)
        if ind_sortie1(1)<ind_entree1(1)&&ind_sortie1(end)<ind_entree1(end)
            born_in = [1;zeros(length(ind_sortie1)-1,1)];
            born_moment = [traj_sejour(i,2);traj_i(ind_entree1(1:length(ind_sortie1)-1),3)];
            die_in = [zeros(length(ind_entree1)-1,1);1];
            die_moment = [traj_i(ind_sortie1((length(ind_sortie1)-length(ind_entree1)+2):end),3);traj_sejour(i,3)];
            conn_position = [(count_e+1:count_e+size(die_in,1))' (count_s+1:count_s+size(born_in,1))'];
        elseif ind_sortie1(1)<ind_entree1(1)&&ind_sortie1(end)>=ind_entree1(end)
            born_in = [1;zeros(length(ind_sortie1)-1,1)];
            born_moment = [traj_sejour(i,2);traj_i(ind_entree1(1:length(ind_sortie1)-1),3)];
            die_in = zeros(length(ind_entree1),1);
            die_moment = traj_i(ind_sortie1((length(ind_sortie1)-length(ind_entree1)+1):end),3);
            conn_position = [(count_e+1:count_e+size(die_in,1))' (count_s+1:count_s+size(born_in,1)-1)'];
        elseif ind_sortie1(1)>=ind_entree1(1)&&ind_sortie1(end)<ind_entree1(end)
            born_in = zeros(length(ind_sortie1),1);
            born_moment = traj_i(ind_entree1(1:length(ind_sortie1)),3);
            die_in = [zeros(length(ind_entree1)-1,1);1];
            die_moment = [traj_i(ind_sortie1((length(ind_sortie1)-length(ind_entree1)+2):end),3);traj_sejour(i,3)];
            conn_position = [(count_e+2:count_e+size(die_in,1))' (count_s+1:count_s+size(born_in,1))'];
        else
            born_in = zeros(length(ind_sortie1),1);
            born_moment = traj_i(ind_entree1(1:length(ind_sortie1)),3);
            die_in = zeros(length(ind_entree1),1);
            die_moment = traj_i(ind_sortie1((length(ind_sortie1)-length(ind_entree1)+1):end),3);
            conn_position = [(count_e+2:count_e+size(die_in,1))' (count_s+1:count_s+size(born_in,1)-1)'];
        end
        %         if ind_sortie1(1)<ind_entree1(1)
        %             born_in = [1;zeros(length(ind_sortie1)-1,1)];
        %             born_moment = [traj_sejour(i,2);zeros(length(ind_sortie1)-1,1)];
        %
        %         else
        %             born_in = zeros(length(ind_sortie1),1);
        %             born_moment = zeros(length(ind_sortie1),1);
        %         end
        
        %         if ind_sortie1(end)<ind_entree1(end)
        %             die_in = [zeros(length(ind_entree1)-1,1);1];
        %             die_moment = [traj_i(ind_sortie1((length(ind_sortie1)-length(ind_entree1)+2):end),3);traj_sejour(i,3)];
        %         else
        %             die_in = zeros(length(ind_entree1),1);
        %             die_moment = traj_i(ind_sortie1((length(ind_sortie1)-length(ind_entree1)+1):end),3);
        %         end
    elseif isempty(ind_sortie1) && ~isempty(ind_entree1)
        born_in = [];
        born_moment = [];
        die_in = [zeros(length(ind_entree1)-1,1);1];
        die_moment = [zeros(length(ind_entree1)-1,1);traj_sejour(i,3)];
    elseif ~isempty(ind_sortie1) && isempty(ind_entree1)
        die_in = [];
        die_moment = [];
        born_in = [1;zeros(length(ind_sortie1)-1,1)];
        born_moment = [traj_sejour(i,2);zeros(length(ind_sortie1)-1,1)];
    else
        born_in = [];
        born_moment = [];
        die_in = [];
        die_moment = [];
    end
    if exist('conn_position')
        for pos_i = 1:size(conn_position,1)
            x(conn_position(pos_i,1),conn_position(pos_i,2))=1;
        end
    end
    
    Sortie=[Sortie;[traj_i(ind_sortie1,2:3) repmat(i,length(ind_sortie1),1) born_in born_moment]];
    Entree=[Entree;[traj_i(ind_entree1,2:3) repmat(i,length(ind_entree1),1)] die_in die_moment];
    count_e = size(Entree,1);
    count_s = size(Sortie,1);
end
if size(Entree,1)>=1 && size(Sortie,1)
    if ~(size(x,1)==size(Entree,1) && size(x,2)==size(Sortie,1))
        x(size(Entree,1),size(Sortie,1))=0;
    end
end
Sortie = array2table(Sortie);
Sortie.Properties.VariableNames={'pos_exit','time_exit','Index','born_in','time_entry'};
    
Entree = array2table(Entree);
Entree.Properties.VariableNames={'pos_entry','time_entry','Index','die_in','time_exit'};
end