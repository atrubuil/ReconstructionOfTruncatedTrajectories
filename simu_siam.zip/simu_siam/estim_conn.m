% Copyright (c) 2020 INRAE - MaIAGE - France.
% Y. Lu, P. Hodara, C. Kervrann, A. Trubuil
function [assi_cplex,diff_val,sol_10opt,objval_exp_v,nb_possible]=estim_conn(Entree,Sortie,tau_d,tau_alpha,Segment,x_true_sol,delta_t,kinem,l_1,opt)
cost_cplex = cost_matrix2(Entree,Sortie,tau_d,tau_alpha,Segment,delta_t,kinem,l_1);
if min(min(cost_cplex))<0
    if opt ==1
        % Find the optimal
        [sol, objval] = mipex1(cost_cplex);
        solution = zeros(size(Entree,1)*size(Sortie,1),1);
        solution(find(cost_cplex<=0))=sol;
        assi_cplex = format_cplex(solution,size(Entree,1),size(Sortie,1),Segment);
        diff_val = nansum(nansum(x_true_sol.*cost_cplex))-objval;
        sol_10opt=[];
        objval_exp_v=[];
        nb_possible=[];
    else
        % Find the nème optimal
        alpha=0.1;
        [sol_10opt,objval_v,objval_exp_v,nb_possible]=mipex1_byrow(cost_cplex,alpha);
        val_min = nansum(nansum(x_true_sol.*cost_cplex));
        %figure;
        lw_prob = objval_exp_v/1.1/sum(objval_exp_v);
        up_prob = objval_exp_v/sum(objval_exp_v);
        lw_true_prob = exp(-val_min)/1.1/sum(objval_exp_v);
        up_true_prob = exp(-val_min)/sum(objval_exp_v);
        figure;
        plot(lw_prob)
        hold on
        plot(up_prob)
        hold on
        plot(repmat(lw_true_prob,length(up_prob),1));
        hold on
        plot(repmat(up_true_prob,length(up_prob),1));
    end
else
    assi_cplex = 1:size(Segment,1);
    diff_val = 0;
end
end
