rng(1)
addpath(genpath('EDAToolboxV2'))% Index Rand
addpath('/home/ynlu/montages_reseau/home_maiage/Analyse/cplex128/cplex128/cplex/matlab/x86-64_linux')
addpath('/home/ynlu/montages_reseau/home_maiage/Analyse/cplex128/cplex128/cplex/examples/src/matlab')
%% First demonstration: the simulation of a movie and the connection result on it.
% Parameters
vstat = 0;% whether all particles have the same speed or not, 0(same speed for all); 1 (different speed among particles)
theta = 0.01;% tan(theta)=v_y/v_x
sigma = 0.3;% sigma^2 is the variance
lambda = 0.08; % birth rate
tau_d = 0.02; % death rate
delta_t = 0.25; % time interval between two image
v_x=0.7; % speed in x-direction
vdir = 0; % whether all particles move to the right direction(0) or they move to left or to right randomly(1)
T_S = 5; % The duration of the registered movie.
fig = [1 2 3 4 5];
% fig(1): number of trajectories at each moment.
% fig(2): Representation of the simulated movie on the surface of a
% cylinder.
% fig(3): Representation of the simulated movie where colors represent the
% time evolution.
% fig(4): Representation of the simulated movie, colored by particle
% indivivdual.
% fig(5): Connection results.
% *Put the corresonding number to 0 if the corresponding figure is to be disabled.*

[~,~,~,ARI,~]=main_segment_connection(vstat,theta,sigma,lambda,tau_d,delta_t,v_x,vdir,T_S,fig);

%% Second demonstration: parameters estimation
theta = 0.15;
fig = [0 0 0 0 0];

nb_repl = 100;
hat_tau_alpha_true_v = zeros(1,nb_repl);
hat_tau_alpha_v = zeros(1,nb_repl);
hat_tau_d_v = zeros(1,nb_repl);
ARI_tot = zeros(nb_repl,2);
Segments=[];
for repl = 1:nb_repl
    repl
    [hat_tau_alpha_true, hat_tau_alpha, hat_tau_d, ARI, Segment] = main_segment_connection(vstat,theta,sigma,lambda,tau_d,delta_t,v_x,vdir,T_S,fig);
    
    hat_tau_alpha_true_v(repl)=hat_tau_alpha_true;
    hat_tau_alpha_v(repl)=hat_tau_alpha;
    hat_tau_d_v(repl)=hat_tau_d;
    ARI_tot(repl,:)=ARI;
    Segments = [Segments;Segment];
end
% tau_alpha
figure(6);
hAx=gca;
boxplot([hat_tau_alpha_true_v' hat_tau_alpha_v'], 'Labels',{'"True" $\tau_\alpha$','$\hat{\tau}_\alpha$'})
hAx.XAxis.TickLabelInterpreter='latex';
title('The "true" and estimated arrival rate $\tau_\alpha$','Interpreter','latex')
% tau_d
figure(7);
boxplot(hat_tau_d_v)
hold on
plot([0.5,1.5],[tau_d,tau_d],'Color','r')
legend('True value')
title 'The estimation of \tau_d'
% v and sigma
v_x=(Segment.v_x-Segment.v_x_true)./Segment.v_x_true;
sigma_x=(sqrt(Segment.sigma_x2)-sqrt(Segment.sigma2_true))./sqrt(Segment.sigma2_true);
v_y=(Segment.v_y-Segment.v_x_true*tan(theta))./(Segment.v_x_true*tan(theta));
sigma_y=(sqrt(Segment.sigma_y2)-sqrt(Segment.sigma2_true))./sqrt(Segment.sigma2_true);
m1 = [v_x v_y sigma_x sigma_y];

figure(8);
hAx=gca;
boxplot(m1,'Labels',{'v_x','v_y','\sigma_x','\sigma_y'})
hAx.XAxis.TickLabelInterpreter='tex';
ylim([-0.5 0.5])
hold on
plot(linspace(0,5,10),zeros(1,10))
title('The normalized error of the estimators')
ylabel 'The normalized error'
% ARI
figure(9);
boxplot(ARI_tot,'Labels',{'True','esitmated'})
ylabel 'ARI'
title({'Connection results mesured by ARI,','with true and with esitmated parameters'})

function [tau_alpha,hat_tau_alpha_shrt,hat_tau_d_shrt_partial,ARI,Segment]=main_segment_connection(vstat,theta,sigma,lambda,tau_d,delta_t,v_x,vdir,T_S,fig)
dura = 30;
[t2D_0, t3D_0, traj_sejour_0, nb_track0]=Simu6_film(sigma,v_x,theta,delta_t,lambda,tau_d,vstat, vdir, dura);

trunc_time = 7.5; % in min
l_1 = 7.3792*2;% Length of the observed zone

% Sortie_prime is used to estimate tau_alpha
[traj_sejour_all,t2D_all,t2D_trans_all,~]=trunc_gene_data(trunc_time*60/delta_t,traj_sejour_0,t2D_0,t3D_0,nb_track0);
[~,Sortie_all]=EntreeSorite2(t2D_trans_all,traj_sejour_all,50-l_1);
T_0_all=(size(t2D_all,2)*delta_t);

% Take a film of 5 min
trunc_value = size(t2D_0,2)-60*T_S/delta_t+1;
[traj_sejour,t2D,t2D_trans,~,t3D_trans,~]=trunc_gene_data(trunc_value,traj_sejour_0,t2D_0,t3D_0,nb_track0);
T_0=(size(t2D,2)*delta_t);

if fig(1)>0 % Draw number of trajectories at each moment
    figure(fig(1));plot((1:length(nb_track0))*delta_t/60,nb_track0);
    hold on
    xlabel 't (min)'
    ylabel 'Number of trajectories'
    title(['$T \sim \exp (1/\lambda), \lambda = $',num2str(lambda), ', $ \tau_d = $', num2str(tau_d)],'interpreter','latex')
    hold on
    %plot(trunc_time*ones(1,101),0:max(nb_track0)/100:max(nb_track0),'r')
end

if fig(3)>0 % Draw trajectories with time evolution
    col = [];
    l_1 = 7.3792*2;
    figure(fig(3))
    xbars = [l_1, 50];
    ybars = [-10 40];
    patch([xbars(1) xbars(2) xbars(2) xbars(1)], [ybars(1) ybars(1), ybars(2) ybars(2)], [0.9 0.9 0.9])
    
    for ti = 1:size(t2D,2)
        ind=(traj_sejour(:,2)<=ti)&(traj_sejour(:,3)>ti);
        coord_ti = [];
        if sum(ind)~=0
            Id=traj_sejour(ind,1);
            for id_t = Id'
                coord_ti = [coord_ti t2D{id_t,ti}];
            end
            Col = zeros(size(coord_ti,2),3);
            if ti<= size(t2D,2)/2
                Col(:,2)=1;
                Col(:,1)=(1-2*ti/size(t2D,2))*204/255;
                Col(:,3)=(1-2*ti/size(t2D,2))*204/255;
            else
                Col(:,2)=(2-2*ti/size(t2D,2))*255/255;
                Col(:,1)=0;
                Col(:,3)=0;
            end
            l_1 = 7.3792*2;
            col = [col;Col];
            figure(fig(3));
            hold on
            scatter(coord_ti(1,:)',coord_ti(2,:)',5,Col,'filled')
            ylim([-10 40]);
            xlim([0 50]);
            daspect([1 1 1])
        end
    end
    figure(fig(3))
    xlabel 'X'
    ylabel 'Y'
    mycolormap = customcolormap([0 0.5 1], [0 0 0; 0 1 0; 0.7987 1.0000 0.7987]);% Copyright (c) 2018, Víctor Martínez-Cagigal
    colorbar;
    colormap(mycolormap);
    title({'Simulated trajectories on a unwrapped surface during 5 min','colors from light to dark represent time'})
end

Colors = [0, 0.4470, 0.7410; 0, 0, 1;0.8500, 0.3250, 0.0980;0, 0.5, 0;
    0.9290, 0.6940, 0.1250;1, 0, 0;0.4940, 0.1840, 0.5560;
    0, 0.75, 0.75;0.4660, 0.6740, 0.1880;0.75, 0, 0.75;
    0.3010, 0.7450, 0.9330;0.75, 0.75, 0;0.6350, 0.0780, 0.1840;
    0.25, 0.25, 0.25];
if fig(4)>0 % To draw trajectories with one color for one track
    figure(fig(4))
    xbars = [l_1, 50];
    ybars = [-10 40];
    xlabel 'X'
    ylabel 'Y'
    title({'The same simulated trajectories as in Fig. 3', 'An individual trajectory is represent in unit color', 'Colors are random'})
    patch([xbars(1) xbars(2) xbars(2) xbars(1)], [ybars(1) ybars(1), ybars(2) ybars(2)], [0.9 0.9 0.9])
    
    nb_track = size(t2D_trans,2);
    
    for tr_i = 1:nb_track
        tr_coor = t2D_trans{tr_i};
        if ~isempty(tr_coor)
            jump = find(abs(diff(tr_coor(:,1)))>38);
            C = Colors(mod(tr_i,size(Colors,1))+1,:);
        
%             if mod(tr_i,size(Colors,1))~=0
%                 C = Colors(mod(tr_i,size(Colors,1)),:);
%             else
%                 C = Colors(size(Colors,1),:);
%             end

            if ~isempty(jump)
                jump = [0;jump;size(tr_coor,1)];
                for k = 1:length(jump)-1
                    tr_coori = tr_coor(jump(k)+1:jump(k+1),:);
                    figure(fig(4))
                    hold on
                    plot(tr_coori(:,1),tr_coori(:,2),'color',C)
                end
            else
                figure(fig(4))
                hold on
                plot(tr_coor(:,1),tr_coor(:,2),'color',C)
            end
        end
    end
end


if fig(2)>0 %Draw a 3D trajectories on a cylinder
    figure(fig(2));
    [X,Y,Z] = cylinder(50/(2*pi),100);
    surf(Z*30,Y,X-min(X(1,:)),'FaceAlpha',0.3, 'EdgeColor', [1 1 1]);
end

if fig(2)>0
    figure(fig(2))
    hold on
    axis([-10 40 -10 10 0 16])
    xlabel 'X'
    ylabel 'Y'
    zlabel 'Z'
    title 'Trajectories on the surface of the cylinder'
    
    nb_track = size(t3D_trans,2);
    for tr_i = 1:nb_track
        tr3D_coor = t3D_trans{tr_i};
        X_axe = tr3D_coor(:,1);
        Y_axe = tr3D_coor(:,2);
        Z_axe = tr3D_coor(:,3);
        if mod(tr_i,size(Colors,1))~=0
            C = Colors(mod(tr_i,size(Colors,1)),:);
        else
            C = Colors(size(Colors,1),:);
        end
        plot3(Y_axe,X_axe,Z_axe,'color',C)
    end
end

[Entree_short_p,Sortie_short_p,x_true_sol]=EntreeSorite2(t2D_trans,traj_sejour,l_1);
[~,Sortie_short,~]=EntreeSorite2(t2D_trans,traj_sejour,50-l_1);

if ~isempty(Sortie_all) && ~isempty(Sortie_short_p) && ~isempty(Entree_short_p)&& ~isempty(Sortie_short)
    tau_alpha = sum(Sortie_all.born_in)/T_0_all;
    %     [Entree_all_p,~,hat_tau_alpha] = tau_alpha_estimation2(50-l_1,l_1,t2D_trans_all,traj_sejour_all,T_0_all,delta_t);
    %     tau_alpha_v(repl)=tau_alpha;
    %     hat_tau_alpha_v(repl)=hat_tau_alpha;
    %     ind_traj_entier = traj_sejour_all(:,3)~=size(t2D_all,2);
    %     hat_tau_d_total(repl) = sum(ind_traj_entier)/(sum(traj_sejour_all(:,3)-traj_sejour_all(:,2)+1))/delta_t;
    %     % estimate tau_d with only partial observed data
    %     hat_tau_d_partial(repl) = sum(Entree_all_p.die_in(Entree_all_p.time_exit~=size(t2D_all,2)))/sum(Entree_all_p.time_exit-Entree_all_p.time_entry)/delta_t;
    %
    %     tau_alpha_shrt = sum(Sortie_short.born_in)/T_0;
    [~,~,hat_tau_alpha_shrt] = tau_alpha_estimation2(50-l_1,l_1,t2D_trans,traj_sejour,T_0,delta_t);
    ind_traj_entier = traj_sejour(:,3)~=size(t2D,2);
    %hat_tau_d_total_shrt = sum(ind_traj_entier)/(sum(traj_sejour(:,3)-traj_sejour(:,2)+1))/delta_t;
    % estimate tau_d with only partial observed data
    hat_tau_d_shrt_partial = sum(Entree_short_p.die_in(Entree_short_p.time_exit~=size(t2D,2)))/sum(Entree_short_p.time_exit-Entree_short_p.time_entry)/delta_t;
    
    Segment = segment_construct(Entree_short_p,Sortie_short_p);
    truth = Segment.Index';
    kinem_var = estim_v_sigma(Segment,t2D_trans,delta_t);
    Segment = [Segment kinem_var];
    v_x_true = traj_sejour(Segment.Index,4);
    v_y_true = v_x_true*tan(theta);
    sigma2_true = sigma^2*ones(size(Segment,1),1);
    Segment = addvars(Segment,v_x_true,'before','v_x');
    Segment = addvars(Segment,v_y_true,'before','v_x');
    Segment = addvars(Segment,sigma2_true,'before','v_x');
    %% To calculate the probability for one configuration
    if length(truth)>1
        
        % Calcul with cplex
        [assi_cplex_1,~]=estim_conn(Entree_short_p,Sortie_short_p,tau_d,tau_alpha,Segment,x_true_sol,delta_t,"true",l_1,1);
        [assi_cplex_2,~]=estim_conn(Entree_short_p,Sortie_short_p,hat_tau_d_shrt_partial,hat_tau_alpha_shrt,Segment,x_true_sol,delta_t,"estim",l_1,1);
        
        ARI(1)= adjrand(assi_cplex_1,truth);
        ARI(2)= adjrand(assi_cplex_2,truth);
    end
else
end

%% Draw the connected results
if fig(5)>0 % Draw the connection results
    figure(fig(5))
    xbars = [l_1, 50];
    ybars = [-10 40];
    xlabel 'X'
    ylabel 'Y'
    title({'Connection results for the same trajectories as in Fig 4.', 'Wrong connections are represented in bold lines'})
    patch([xbars(1) xbars(2) xbars(2) xbars(1)], [ybars(1) ybars(1), ybars(2) ybars(2)], [0.9 0.9 0.9])
    Colors = [0, 0.4470, 0.7410; 0, 0, 1;0.8500, 0.3250, 0.0980;0, 0.5, 0;
        0.9290, 0.6940, 0.1250;1, 0, 0;0.4940, 0.1840, 0.5560;
        0, 0.75, 0.75;0.4660, 0.6740, 0.1880;0.75, 0, 0.75;
        0.3010, 0.7450, 0.9330;0.75, 0.75, 0;0.6350, 0.0780, 0.1840;
        0.25, 0.25, 0.25];
    nb_track = max(assi_cplex_1);
    Id_tr_falseconn=[];
    for i = 1:nb_track
        segs = find(assi_cplex_1 == i);
        sg_info = Segment(segs,:);
        sg_info = sortrows(sg_info,3);
        
        C = Colors(mod(sg_info.Index(1),size(Colors,1))+1,:);
        if length(unique(sg_info.Index))==1 && sum(Segment.Index == sg_info.Index(1))==length(segs)
            LineWidth = 1;
        else
            LineWidth = 2;
            Id_tr_falseconn=[Id_tr_falseconn;sg_info.Index];
        end
        for k = 1:length(segs)
            a = sg_info.Index(k);
            tr_coor = t2D_trans{a};
            l = find(tr_coor(:,3)==sg_info.time_entry(k));
            r = find(tr_coor(:,3)==sg_info.time_exit(k));
            sg_coor = tr_coor(l:r,:);
            point_enter = tr_coor(l,2);
            figure(fig(5))
            hold on
            plot(sg_coor(:,1),sg_coor(:,2),'color',C,'LineWidth',LineWidth)
            if k>1
                figure(fig(5))
                hold on
                plot([l_1 50],[point_exit point_enter],'--','color',C,'LineWidth',LineWidth)
            end
            point_exit = tr_coor(r,2);
        end
    end
    Id_tr_falseconn=unique(Id_tr_falseconn);
     for i = 1:length(Id_tr_falseconn)
         tr_i = Id_tr_falseconn(i);
        tr_coor = t2D_trans{tr_i};
        if ~isempty(tr_coor)
            jump = find(abs(diff(tr_coor(:,1)))>38);
            C = Colors(mod(tr_i,size(Colors,1))+1,:);
        
%             if mod(tr_i,size(Colors,1))~=0
%                 C = Colors(mod(tr_i,size(Colors,1)),:);
%             else
%                 C = Colors(size(Colors,1),:);
%             end

            if ~isempty(jump)
                jump = [0;jump;size(tr_coor,1)];
                for k = 1:length(jump)-1
                    tr_coori = tr_coor(jump(k)+1:jump(k+1),:);
                    figure(fig(4))
                    hold on
                    plot(tr_coori(:,1),tr_coori(:,2),'color',C,'LineWidth',2)
                end
            else
                figure(fig(4))
                hold on
                plot(tr_coor(:,1),tr_coor(:,2),'color',C,'LineWidth',2)
            end
        end
    end
end

end



