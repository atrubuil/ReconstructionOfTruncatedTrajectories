function Segment = segment_construct(Entree,Sortie)
% Construct the matrix for linear equation
Segment = [];
% Segment: index_entry index_exit time_entry time_exit
for i = 1:size(Entree,1)
    e_i = Entree(i,:);
    if e_i.die_in==1
        s_i = [i,NaN];
    else
        j=find(Sortie.Index==e_i.Index& Sortie.time_exit==e_i.time_exit);
        s_i = [i,j];
    end
        temps_i = [e_i.time_entry e_i.time_exit];
    Segment(i,:)=[s_i,temps_i,e_i.Index];
end
count = 1;
for m = 1:size(Sortie,1)
    sortie_i = Sortie(m,:);
    if sortie_i.born_in==1
    s_i = [NaN,m];
    temps_i = [sortie_i.time_entry sortie_i.time_exit];
    Segment(size(Entree,1)+count,:)=[s_i,temps_i,sortie_i.Index];
    count = count+1;
    end
end
Segment = array2table(Segment);
Segment.Properties.VariableNames={'ID_entree','ID_sortie','time_entry','time_exit','Index'};
end
